<?php
session_start()
?>

<?php
  
  if(!($_SESSION['email']) || !($_SESSION['password']))
  {     
    
	   header ("Location: login.php"); 
  }
 
  else {
	  
?>
<html lang="en">

	<head>
		<title>Dashboard</title>
        <link rel="stylesheet" type="text/css" href="css/mystyle.css">
	</head>
	<body style="background-image:url(css/picture/img_3.jpg)">

		<div class="topnav">
		  <a href="index.html">Home</a>
		  <a href="booking.php">Buy ticket</a>
		  <a href="cancel_ticket.php">Cancel tickets</a>
		  <a href="show_ticket.php">Show ticket</a>
		   <a href="logout.php">Logout </a> 

		</div>
      
	 
	</body>
</html>

<?php
  }
  
?>
