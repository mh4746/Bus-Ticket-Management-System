<?php
session_start();
?>


<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" href="css/mystyle.css">
	</head>
	<body>
 
	
		   <div style="padding-left:16px">
			  <h2><center>Admin panel page </center></h2><br><br>
		  </div>
		  
           <form method="post" action="">
		
			<div class="input-group">
			  <label>Email</label>
			  <input type="email" name="ademail">
			</div>
			
			<div class="input-group">
			  <label>Password</label>
			  <input type="password" name="adpassword_1">
			</div>
		 
			<div class="input-group">
			  <button type="submit" class="btn" name="submit">Login</button>
			</div>
			
			<?php
			
		      include "conn.php";
		       	
		     if(isset($_POST['submit']))
		     {   
	            
		       	 $email = $_POST['ademail'];
                 $pass= $_POST['adpassword_1'];
			     
                   $sql = "SELECT email, password FROM admin WHERE email = '$email' AND password = '$pass' ";
                	$records = $con->query($sql);
                    $Email = "";
					$password = "";
					while($rows = $records->fetch_assoc())
					{
						$Email = $rows['email'];
						$password = $rows['password'];
					}
			  		if($Email == $email && $pass==$password && ($Email!="" && $password!=""))
					{
						//echo "Successfully log in";
					 $_SESSION['ademail'] = $Email;
					 $_SESSION['adpassword'] = $password;
						header ("Location: admin.php");
					}	
                   else
                   echo "Error Email or password <br>";					   
              } 
			  
			 ?>
			 
	 
	</body>
	
</html>
