<?php

$con=new mysqli('localhost','root','','bus')
 or die('unable to connect');
 
   

?>