<!DOCTYPE html>
<html lang="en">

	<head>
		<title>CSS Template</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="css/mystyle.css">
	</head>
	<body>

		<div class="topnav">
		  <a href="#">Home</a>
		  <a href="booking.php">Buy ticket</a>
		  <a href="help.php">Help</a>
		  <a href="registration.php">Creat account</a>
		  <a href="login.php">Login</a>
		</div>
       <img 
		<div class="content">
		  
		</div>

	 
	</body>
	
</html>
