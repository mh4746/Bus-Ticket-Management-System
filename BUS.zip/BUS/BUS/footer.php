<html>
      
      <?php
         
	  echo "<center><h1>Copyright © 2018, Online bus ticket management System Team </h1></center>";
      
      ?>   

</html>