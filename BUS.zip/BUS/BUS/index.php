<html>

	<body>
		<head>
			<br><br><br><h1><center> Online bus ticket management system </center></h1><br>
		</head>
		  
	 
	 <?php
	 
	    echo "odfkkkkkjgggggggggggggggggggggk";
	   include "footer.php";
	 
	 ?>
	</body>

</html>