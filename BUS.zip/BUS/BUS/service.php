<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" href="css/mystyle.css">
	</head>
	<body>

		<div class="topnav">
			  <a class="active" href="index.html">Home</a>
			  <a href="service.php">Service</a>
			  <a href="help.php">Help</a>
			  <a href="about.php">About</a>
			  <a href="registration.php">Registartion</a>
			  <a href="login.php">Login</a>
		</div>
		
		 

		   <div style="padding-left:16px">
			  <h2><center>Welcome to online bus ticket management system </center></h2><br><br>
		  </div>
		    <p>
			
			
			AKJDH SAKDFHN ksdzf skzlfj sdkfjn sdzkgjn dgvkjdxfngbvjk dxfkgvn><br>
			ksfskdfj sfkdnskdjf sdkjfvnoiwer weaihfierg askjbnc sgh nsfkn gvkn <br>
			
			
			</p>
			
			
	</body>
</html>
