<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" href="css/mystyle.css">
	</head>
	<body>

		<div class="topnav">
			  <a class="active" href="index.html">Home</a>
			  <a href="service.php">Service</a>
			  <a href="help.php">Help</a>
			  <a href="about.php">About</a>
			  <a href="registration.php">Registartion</a>
			  <a href="login.php">Login</a>
		</div>
		 
		 <p>
		 
		     <h1>How to buy a tickte </br></h1>
			 
			 <h3>1. Go to wwww.onlinebusticket managementsystem.com</br></h3>
			 <h3>2. Give your leaving from, going to & journey date in search box then click search.</br></h3>
			 <h3>3. Choose your suitable Time, Bus and click on this list. </br></h3>
			 <h3>4. Choose your seat which colour is white.</br></h3>
			 <h3>5. Give your all information.<br></h3>
			 <h3>6. Choose your payment method.<br></h3>
			 <h3>7. We Accept: Master Card, VISA, Amex, DBBL NEXUS, bKash, Sure Cash.</br></h3>
			 <h3>8. Click on Confirm button.</br></h3>
		     <h3>9. Follow the process step by step.....</br></h3>
			 <h3>10. If tickets Confirm. you get a sms ticket on your mobile.</br></h3>
			<h3>Enjoy Your Journey!!!!</br></h3>
			<h2>Need any help call to 01*********</h2>.
		 </p>
		 
        <footer>
			<?php
			include "footer.php"
			?>
     </footer>
	 
	</body>
</html>
